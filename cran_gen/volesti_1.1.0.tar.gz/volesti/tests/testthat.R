library(testthat)
#library(volesti)

test_check("volesti")
