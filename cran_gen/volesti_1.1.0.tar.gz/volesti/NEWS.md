# volesti 1.0.0

* This is the first release of volesti R-Package.

# volesti 1.0.1

* Fix some bugs for solaris os.

# volesti 1.0.2

* Remove r-striper to avoid CRAN policy violation.

# volesti 1.0.3

* Fix CRAN warnings.

# volesti 1.1.0

* New volume computation algorithm.
* Billiard walk for uniform sampling.
* Modified exact volume computation function.
* Implementation and evaluation of PCA method for zonotope approximation.
* Boundary sampling.
* Improved functionality for finance applications.
* Improved names for functions and input variables.
* Use exclusively Eigen/BH library for linear algebra.
